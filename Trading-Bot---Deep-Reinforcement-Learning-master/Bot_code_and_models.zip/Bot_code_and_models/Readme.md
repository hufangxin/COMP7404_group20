# Dependencies 
Dependecies:    
* prettytable (`pip install prettytable`)  
* PyTorch
* tqdm
* pandas
* numpy
* matplotlib
    
To Run Pretrained Models:   
* `python main.py`  

To Run Train and Test:  
* `python train_test.py`

